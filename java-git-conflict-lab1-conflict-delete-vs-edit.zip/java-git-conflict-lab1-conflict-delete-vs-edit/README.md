# Java Git Conflict Lab

## Objetivo
Aprender a detectar y resolver conflictos de merge reales en Java.

## Instrucciones generales
1. Situarse en main
2. Hacer merge de una rama conflictiva
3. Resolver conflictos
4. Compilar
5. Ejecutar
6. Justificar la solución
